package elevatorsim.ui;

import java.util.Timer;
import java.util.TimerTask;

public class DrawTimer extends TimerTask {
    
    @Override
    public void run(){
        //draw the simulation window
    }
}
