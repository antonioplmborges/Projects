package elevatorsim.controller;

import java.util.Timer;
import java.util.TimerTask;

public class SimTimer extends TimerTask {
    
    @Override
    public void run(){
        //update all data objects
    }
    
}
