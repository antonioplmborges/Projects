package elevatorsim.controller;

public class SimController {
    
    private SimTimer timer;
    
    public void loadScenario(){
        
    }
    
    public void runSimulation(){
        
    }
    
    public void update(){
        
    }
    
    public void getState(){
        
    }
}
