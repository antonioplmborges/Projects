package elevatorsim.data;

import java.util.ArrayList;


public class Scheduler {
    
    public void dispatch(ArrayList<Elevator> el, int floorNumber){
        //decide which elevator is going
        //add the request to the elevator queue
    }
}
