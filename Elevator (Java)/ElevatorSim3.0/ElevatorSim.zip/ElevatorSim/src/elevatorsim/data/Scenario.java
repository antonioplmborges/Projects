package elevatorsim.data;

public class Scenario {
    
}
