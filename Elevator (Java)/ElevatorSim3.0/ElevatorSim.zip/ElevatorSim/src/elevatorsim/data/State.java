package elevatorsim.data;

import java.util.ArrayList;

public class State {
    
    private ElevatorBank bank;
    private ArrayList<Floor> floors;
    
    public void update(){
        
    }
}
