package elevatorsim.data;

import java.util.ArrayList;

public class Elevator {
    
    private ArrayList<Person> riders;
    
    public Floor getCurrentFloor(){
        
        return null;
    }
    
    public void update(){
        
    }
    
    public void addRequest(Floor floor){
        
    }
       
    
}
