import hw.generics._
import ListFunctions._

class TestSuite extends org.scalatest.FunSuite {


}
